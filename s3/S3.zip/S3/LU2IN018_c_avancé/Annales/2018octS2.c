#include <stdio.h>
#include <stdlib.h>

extern int nb_valeurs;
extern int nb_categories;

typedef struct _data *PData;
typedef struct _data
{
    double *valeur;
    int categorie;
    PData suivant;
} Data;

PData creer_data(double *pval, int categorie){
    PData res = malloc(sizeof(PData));
    res->valeur = malloc(sizeof(double)*nb_valeurs);
    res->categorie = categorie;
    int i;
    for(i=0 ; i<nb_valeurs ; i++){
        res->valeur[i] = pval[i];
    }
    res->suivant = NULL;
    return res;
}

void liberer_data(PData pliste){
    PData backup;
    while(pliste){
        backup = pliste->suivant;
        free(pliste);
        pliste = backup;
    }
}

PData ajouter_data(PData pliste, PData pajout){
    PData new = malloc(sizeof(PData));
    new = creer_data(pajout->valeur, pajout->categorie);
    new->suivant = pliste;
    return new;
}

void ecrire_data(PData pliste, const char *nom){
    FILE *f = fopen(nom, 'w');
    fprintf(f, "%d %d \n", nb_valeurs, nb_categories);
    while(pliste){
        for(int i=0 ; i<nb_valeurs ; i++){
            fprintf(f, "%1f ", pliste->valeur[i]);
        }
        fprintf(f, "%d\n", pliste->categorie);
        pliste=pliste->suivant;
    }
    fclose(f);
}

PData lire_data(const char *nom_fichier){
    PData res = malloc(sizeof(PData));
    FILE *f = fopen(nom_fichier, 'r');
    fscanf(f, " %d %d", &nb_valeurs, &nb_categories);

    
}

int main(){

    return 0;
}