typedef struct _image_t
{
    unsigned long w; // largeur en pixels
    unsigned long h; // hauteur en pixels
    unsigned char *buff; // w x h octets correspondant aux pixels
} image_t;