#include <stdlib.h>
#include <stdio.h>

void bonjour(){
    printf("Bonjour monde c'est vendredi!\n");
}

int main(){
    bonjour();
    return 0;
}