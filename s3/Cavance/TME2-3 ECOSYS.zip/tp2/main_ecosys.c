#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <strings.h>
#include "ecosys.h"

#define NB_PROIES 20
#define NB_PREDATEURS 20
#define T_WAIT 40000


/* Parametres globaux de l'ecosysteme (externes dans le ecosys.h)*/
float p_ch_dir=0.01;
float p_reproduce_proie=0.4;
float p_reproduce_predateur=0.5;
int temps_repousse_herbe=-15;


int main(void) {

  //initialisation des listes d'animaux, de l'énergie et du monde
  Animal *liste_proie = NULL;
  Animal *liste_predateur = NULL;

  float energie=10.0;
  int monde[SIZE_X][SIZE_Y];

  //ajout des proies et des prédateurs à l'écosystème
  for(int i=0;i<20;i++){
		ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,energie,&liste_proie);
		ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,energie,&liste_predateur);
		assert(liste_proie);
		assert(liste_predateur);
	}

  /*A completer. Part 2:*/

   /* exercice 4, questions 2 et 4*/

    // Animal *a=creer_animal(0,1,10);
    // afficher_ecosys(a,NULL);

    // déplacement de l'animal a
    // bouger_animaux(a);

    // afficher_ecosys(a,NULL);

    // afficher_ecosys(liste_predateur,liste_proie);
    // reproduce(&liste_proie,p_reproduce_proie);
    // reproduce(&liste_predateur,p_reproduce_predateur);
    // afficher_ecosys(liste_predateur,liste_proie);

    /*exercice 6, question 2*/

    srand(time(NULL));

    /*while(liste_proie){
      rafraichir_proies(&liste_proie,monde);
      afficher_ecosys(liste_predateur, liste_proie);
      usleep(1000000);
    }*/

    //rafraîchit les proies et prédateurs jusque la mort de tous les animaux d'une liste 
    while(liste_predateur && liste_proie){
      rafraichir_predateurs(&liste_predateur,&liste_proie);
      rafraichir_proies(&liste_proie,monde);
      afficher_ecosys(liste_predateur, liste_proie);
      usleep(100000);
    }   

    liberer_liste_animaux(liste_proie);
    liberer_liste_animaux(liste_predateur);

  return 0;
}