#include <assert.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "ecosys.h"

float p_ch_dir=0.01;
float p_reproduce_proie=0.4;
float p_reproduce_predateur=0.5;
int temps_repousse_herbe=-15;


int main(){
  srand(time(NULL));
  Animal *liste_proie = NULL, *liste_predateur = NULL;
  float energie=10.0;
  
	for(int i=0;i<20;i++){
		ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,energie,&liste_proie);
		ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,energie,&liste_predateur);
		assert(liste_proie); assert(liste_predateur);
	}

  // int nbpro= compte_animal_it(liste_proie);
  // int nbpre=compte_animal_it(liste_predateur);
  // int nbpro2=compte_animal_rec(liste_proie);
  // int nbpre2=compte_animal_rec(liste_predateur);
  // printf("Compteur proies it : %d\nCompteur predateurs it : %d\nCompteur proies rec : %d\nCompteur predateurs rec : %d\n", nbpro, nbpre, nbpro2, nbpre2);
	
	//afficher_ecosys(liste_proie,liste_predateur);
	//liste_proie=liberer_liste_animaux(liste_proie);
	//liste_predateur=liberer_liste_animaux(liste_predateur);
	//afficher_ecosys(liste_proie,liste_predateur);
  
  //suppresion d'une proie
	// enlever_animal(&liste_proie,liste_proie->suivant);
  //suppression d'un prédateur
  // enlever_animal(&liste_predateur,liste_predateur->suivant);
	// afficher_ecosys(liste_predateur, liste_proie);

  //partie 2 exercice 3
  //écriture des stats des listes de proies et prédateurs dans le fichier ecos.txt
  ecrire_ecosys("ecos.txt", liste_predateur, liste_proie);


  Animal *liste_proie2 = NULL, *liste_predateur2 = NULL;
  //lecture des nouvelles listes de proies et prédateurs dans le fichier ecos.txt
  lire_ecosys("ecos.txt", &liste_predateur2, &liste_proie2);
  afficher_ecosys(liste_predateur2, liste_proie2);

  //partie 1 exercice 6 question 5
  //libére la mémoire des listes
  liberer_liste_animaux(liste_proie);
  liberer_liste_animaux(liste_predateur);
  liberer_liste_animaux(liste_proie2);
  liberer_liste_animaux(liste_predateur2);
  return 0;
	
}
