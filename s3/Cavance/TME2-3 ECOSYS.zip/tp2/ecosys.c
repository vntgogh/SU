//INES HARRAOUI 21204786
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "ecosys.h"
#include <string.h>

/* PARTIE 1*/
/* Fourni: Part 1, exercice 4, question 2 */

Animal *creer_animal(int x, int y, float energie) {
  //crée un nouvel animal avec des coordonnées (x, y) et une énergie données

  Animal *na = (Animal *)malloc(sizeof(Animal));
  assert(na); // vérifie que l'allocation a réussi
  na->x = x;
  na->y = y;
  na->energie = energie;
  na->dir[0] = rand() % 3 - 1;
  na->dir[1] = rand() % 3 - 1;
  na->suivant = NULL;
  return na;
}


/* Fourni: Part 1, exercice 4, question 3 */

Animal *ajouter_en_tete_animal(Animal *liste, Animal *animal) {
  //ajoute un animal en tête d'une liste d'animaux

  assert(animal);
  assert(!animal->suivant); //on s'assure que le champ suivant est vide
  animal->suivant = liste;
  return animal;
}

/* A faire. Part 1, exercice 6, question 2 */
void ajouter_animal(int x, int y,  float energie, Animal **liste_animal) {
  //ajoute un animal à une liste animale avec les caractéristiques données
  
	assert(x>=0);assert(y>=0); //vérifie que x,y sont compris entre 0 et SIZE_(X,Y)
  assert(x<=SIZE_X);assert(y<=SIZE_Y); 

	assert(liste_animal);
  //crée un nouvel animal et l'ajoute en tête de la liste
	Animal *nva=creer_animal(x,y,energie);
	assert(nva);
	*liste_animal=ajouter_en_tete_animal(*liste_animal,nva);
	
}

/* A Faire. Part 1, exercice 5, question 5 */
void enlever_animal(Animal **liste, Animal *animal) {
  //supprime un animal donné d'une liste d'animaux    

  Animal *cour = *liste;
  Animal *prec = NULL;

  //parcourt la liste jusqu'à trouver l'animal à supprimer
  while (cour){
    //si l'animal est trouvé 
    if (cour == animal){ 
      //si l'animal n'est pas en tête de liste
      if (prec){   
        //rechainage en pointant son suivant vers le suivant du courant(contourne l'animal)
        prec->suivant = cour->suivant; 
      }else{
        //met à jour la tête de liste si l'animal est en tête de liste
        *liste = cour->suivant;  
      }
      //libère la mémoire occupée par l'animal supprimé
      free(cour);
      break;
    }
    prec = cour;
    cour = cour->suivant;
  }
}

 
/* A Faire. Part 1, exercice 6, question 7 */
Animal* liberer_liste_animaux(Animal *liste) {
  // libère la mémoire occupée par une liste d'animaux

   while(liste){
   Animal *tmp=liste;
   liste=liste->suivant;
   free(tmp);
   }
  return NULL;
}

/* Fourni: part 1, exercice 4, question 4 */
unsigned int compte_animal_rec(Animal *la) {
  //compte récursivement le nombre d'animaux d'une liste

  if (!la){
    return 0;
  } 
  return 1 + compte_animal_rec(la->suivant);
}

/* Fourni: part 1, exercice 4, question 4 */
unsigned int compte_animal_it(Animal *la) {
  //compte itérativement le nombre d'animaux d'une liste

  int cpt=0;
  while (la) {
    cpt++;
    la=la->suivant;
  }
  return cpt;
}

/* Part 1. Exercice 5, question 1, ATTENTION, ce code est susceptible de contenir des erreurs... */
void afficher_ecosys(Animal *liste_proie, Animal *liste_predateur) {
  //affiche l'écosystème des proies, prédateurs ainsi que leur nombres

  unsigned int i, j;
  char ecosys[SIZE_X][SIZE_Y];
  Animal *pa=NULL;

  /* initialise le tableau */
  for (i = 0; i < SIZE_X; ++i) {
    for (j = 0; j < SIZE_Y; ++j) {
      ecosys[i][j]=' ';
    }
  }

  /* ajoute les proies */
  pa = liste_proie;
  while (pa) {
    ecosys[pa->x][pa->y] = '*';
    pa=pa->suivant;
  }

  /* ajoute les predateurs */
  pa = liste_predateur;
  while (pa) {
      if ((ecosys[pa->x][pa->y] == '@') || (ecosys[pa->x][pa->y] == '*')) { /* proies aussi present */
        ecosys[pa->x][pa->y] = '@';
      } else {
        ecosys[pa->x][pa->y] = 'O';
      }
    pa = pa->suivant;
  }

  /* affiche le tableau */
  printf("+");
  for (j = 0; j < SIZE_Y; ++j) {
    printf("-");
  }  
  printf("+\n");
  for (i = 0; i < SIZE_X; ++i) {
    printf("|");
    for (j = 0; j < SIZE_Y; ++j) {
      putchar(ecosys[i][j]);
    }
    printf("|\n");
  }
  printf("+");
  for (j = 0; j<SIZE_Y; ++j) {
    printf("-");
  }
  printf("+\n");
  
  int nbpro=compte_animal_it(liste_proie);
  int nbpre=compte_animal_it(liste_predateur);
  
  printf("Nb proies : %5d\tNb predateurs : %5d\n", nbpro, nbpre);

}

void clear_screen() {
  printf("\x1b[2J\x1b[1;1H");  /* code ANSI X3.4 pour effacer l'ecran */
}

/* PARTIE 2*/

/*Part 2. Exercice 1, question 1*/

void ecrire_ecosys(const char *nom_fichier, Animal *liste_proie, Animal *liste_predateur) {
  //écrit les données de chaque proie et chaque prédateur dans un fichier donné

	FILE *f = fopen(nom_fichier, "w");
	if(f == NULL){
    printf("Erreur d'ouverture de : %s\n", nom_fichier);
  }

  //écriture des proies dans le fichier
	fprintf(f, "<proies>\n");
	while(liste_proie) {
		fprintf(f, "x = %d, y = %d, dir = [%d %d], energie = %f\n", liste_proie->x, liste_proie->y, liste_proie->dir[0], liste_proie->dir[1], liste_proie->energie);
		liste_proie = liste_proie->suivant;
		}
	fprintf(f, "</proies>\n");

  //écriture des prédateurs dans le fichier
  fprintf(f, "<predateurs>\n");
	while(liste_predateur) {
		fprintf(f, "x = %d, y = %d, dir = [%d %d], energie = %f\n", liste_predateur->x, liste_predateur->y, liste_predateur->dir[0], liste_predateur->dir[1], liste_predateur->energie);
		liste_predateur = liste_predateur->suivant;
		}
	fprintf(f, "</predateurs>");
	fclose(f);
}


void lire_ecosys(const char *nom_fichier, Animal **liste_proie, Animal **liste_predateur) {
  //lit l'écosystème depuis un fichier et crée les listes de proies et de prédateurs
	int x, y, dir[2];
	float e;
	FILE *f = fopen(nom_fichier,"r");
	if(f == NULL){
    printf("Erreur d'ouverture de : %s\n", nom_fichier);
  }

  char buffer[256]; //sert à stocker chaque ligne temporairement

  //lecture des proies du fichier

	//lit la premiere ligne du fichier f et la stocke dans buffer
  fgets(buffer, 256, f); 

	//vérifie que les deux chaines soient les mêmes
  assert(strncmp(buffer, "<proies>", 8)==0); 

  //passe à la ligne suivante(=premier animal de la liste)
	fgets(buffer, 256, f);

  //tant que la ligne dans buffer n'est pas </proies>
	while(strncmp(buffer, "</proies>", 9) != 0) {

    //attribue les valeurs extraites aux variables x,y,dir[0],dir[1],e 
    //et renvoie le nombre de valeurs bien attribuées
		sscanf(buffer, "x = %d, y = %d, dir = [%d %d], energie = %f\n", &x, &y, &dir[0], &dir[1], &e);
		
    Animal *a = creer_animal(x, y, e);
		a->dir[0] = dir[0];
		a->dir[1] = dir[1];
		a->suivant = *liste_proie;
		*liste_proie = a; //ajoute l'animal à la liste de proies
		fgets(buffer, 256, f); //passe aux stats de l'animal suivant
	}

  //lecture des prédateurs du fichier

	fgets(buffer, 256, f);

  //vérifie que les deux chaines soient les mêmes
	assert(strncmp(buffer, "<predateurs>", 12)==0);

	fgets(buffer, 256, f);

  //tant que la ligne dans buffer n'est pas </predateurs>
	while(strncmp(buffer, "</predateurs>", 13) != 0) {
		sscanf(buffer, "x = %d, y = %d, dir = [%d %d], energie = %f\n", &x, &y, &dir[0], &dir[1], &e);
		Animal *a = creer_animal(x, y, e);
		a->dir[0] = dir[0];
		a->dir[1] = dir[1];
		a->suivant = *liste_predateur;
		*liste_predateur = a; //ajoute l'animal à la liste de prédateurs
		fgets(buffer, 256, f); //extrait la ligne suivante du fichier f
	}
	fclose(f);
}


/* Part 2. Exercice 4, question 1 */

void bouger_animaux(Animal *la) {
  //déplace les animaux dans l'écosystème

  while(la){
    la->x=(la->x+la->dir[0]+SIZE_X)%SIZE_X;
    la->y=(la->y+la->dir[1]+SIZE_Y)%SIZE_Y;
    if ((float)rand()/(float) RAND_MAX<=p_ch_dir){
      la->dir[0]=(rand()%3)-1;
      la->dir[1]=(rand()%3)-1;
    }
    la=la->suivant;
  }
}

/* Part 2. Exercice 4, question 3 */


void reproduce(Animal **liste_animal, float p_reproduce) {
  //fait se reproduire les animaux dans la liste avec une probabilité donnée

  Animal *p=*liste_animal;
  while(p){
    if((float)rand()/RAND_MAX <= p_reproduce){
      ajouter_animal(p->x, p->y, (p->energie/2.0), &(*liste_animal));
      p->energie/=2.0;
    }
    p=p->suivant;
  }
}


/* Part 2. Exercice 6, question 1 */
void rafraichir_proies(Animal **liste_proie, int monde[SIZE_X][SIZE_Y]) {
  //rafraîchit les proies dans l'écosystème en les faisant bouger et se reproduire

  Animal *p=*liste_proie;
  bouger_animaux(*liste_proie);

  while(p){
    //met à jour l'énergie des proies et retire celles qui n'ont plus d'énergie
    p->energie-=1; 

    //si l'énergie de la proie est épuisée 
    if(p->energie<0){

      //retire la proie de la liste
      Animal *psuiv=p->suivant;
      enlever_animal(liste_proie,p);
      p=psuiv;
      continue; //passe à la proie suivante(p=p->suivant ne sera pas exécuté pour cette itération)
    }
    p=p->suivant;
  }
  //reproduction des proies avec une probabilité p_reproduce_proie
  reproduce(liste_proie,p_reproduce_proie);
}

/* Part 2. Exercice 7, question 1 */
Animal *animal_en_XY(Animal *l, int x, int y) {
	//renvoie le pointeur sur la case (x,y) s'il y a une proie à cet emplacement
  while(l) {
		if ((l->x == x) && (l->y == y)) {
			return l;
		}
		l = l->suivant;
	}
  //renvoie null sinon
  return NULL;
} 


/* Part 2. Exercice 7, question 2 */
void rafraichir_predateurs(Animal **liste_predateur, Animal **liste_proie) {
  /*on fait bouger chaque animal jusqu'à ce que son énergie se vide
  on reproduit tout le monde à la fin*/
  Animal *p=*liste_predateur;
  bouger_animaux(*liste_predateur);

  while(p){
    //met à jour l'énergie des prédateurs et retire celles qui n'ont plus d'énergie
    p->energie-=1;

    //si l'énergie du prédateur est épuisée 
    if(p->energie<0){

      //retire le prédateur de la liste
      Animal *ansuiv=p->suivant;
      enlever_animal(liste_predateur,p);
      p=ansuiv;
      continue; //passe au prédateur suivant
    }

    //verifie s'il y a une proie sur la meme case qu'un predateur pour la tuer
    Animal *tmp = animal_en_XY(*liste_proie, p->x, p->y);
    while (tmp) { 

      //le predateur recupere l'energie de la proie tuee
      p->energie += tmp->energie; 

      // la proie tuee est enlevee de liste_proie
      enlever_animal(liste_proie, tmp); 

      //on verifie s'il n'y a pas d'autre proie situee sur cette meme case
      tmp = animal_en_XY(*liste_proie, p->x, p->y);       
    }
		p = p->suivant;
	}
  //reproduction des prédateurs avec une probabilité p_reproduce_predateur
	reproduce(liste_predateur, p_reproduce_predateur);
}

/* Part 2. Exercice 5, question 2 */
void rafraichir_monde(int monde[SIZE_X][SIZE_Y]){
   /*A Completer*/
}

