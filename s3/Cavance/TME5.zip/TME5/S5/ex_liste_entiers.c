
#include <stdlib.h>
#include "liste.h"
#include "devel.h"
#include "fonctions_entiers.h"

int main(void) {

	PListe pl = malloc(sizeof(Liste));
	if (pl == NULL){
	printf("Erreur d'allocation");
	return 1;
	}

	pl->elements = NULL;
	pl->dupliquer = dupliquer_int;
	pl->copier = copier_int;
	pl->detruire = detruire_int;
	pl->afficher = afficher_int;
	pl->comparer = comparer_int;
	pl->ecrire = ecrire_int;
	pl->lire = lire_int;

	int *a = (int *)malloc(sizeof(int));
	int *b = (int *)malloc(sizeof(int));
	int *c = (int *)malloc(sizeof(int));
	*a = 12; *b = 24; *c = 35;

	inserer_debut(pl, (void *)a);
	inserer_debut(pl, (void *)b);
	inserer_debut(pl, (void *)c);

	printf("==========================================================\n"); 
	printf("Affichage de la liste :\n");
	afficher_liste(pl); 
	printf("==========================================================\n"); 

	int *test_int = pl->dupliquer((void *)a);
	printf("Test fonction dupliquer_int() (résultat attendu 12) : %d\n", *test_int);

	*test_int = 0;
	pl->copier((void *)b, (void *)test_int);
	printf("Test de la fonction copier_int() : src = %d, dst = %d\n", *b, *test_int);

	printf("Test de la fonction afficher_int() (résultat attendu 35) : "); pl->afficher((void *)c); printf("\n\n");

	printf("Test de comparer_int(12,24) : %d\n", pl->comparer((void *)a, (void *)test_int));
	printf("Test de comparer_int(24,24) : %d\n", pl->comparer((void *)b, (void *)test_int));
	printf("Test de comparer_int(25,24) : %d\n\n", pl->comparer((void *)c, (void *)test_int));

	FILE *fw = fopen("testExo1_ecrire.txt", "w");
	pl->ecrire((const void *)c, fw);
	pl->ecrire((const void *)a, fw);
	fclose(fw);

	FILE *fr = fopen("testExo1_ecrire.txt", "r");
	int *test_ecrire_lire = pl->lire(fw);
	fclose(fr);

	printf("Test de open_int() et lire_open() : %d\n", *test_ecrire_lire);

	pl->detruire((void *)a); pl->detruire((void *)b); pl->detruire((void *)c); pl->detruire((void *)test_int); pl->detruire((void *)test_ecrire_lire);
	detruire_liste(pl);
	return 0;
}
