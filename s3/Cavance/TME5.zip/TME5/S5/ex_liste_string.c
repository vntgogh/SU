
#include <stdlib.h>
#include "liste.h"
#include "devel.h"
#include "fonctions_string.h"

int main(void) {

  
	PListe pl = malloc(sizeof(Liste));
	if (pl == NULL){
	printf("Erreur d'allocation");
	return 1;
	}

	pl->elements = NULL;
	pl->dupliquer = dupliquer_str;
	pl->copier = copier_str;
	pl->detruire = detruire_str;
	pl->afficher = afficher_str;
	pl->comparer = comparer_str;
	pl->ecrire = ecrire_str;
	pl->lire = lire_str;

	char *str1 = malloc(sizeof(char)*512); strcpy(str1, "Hello World !");
  char *str2 = malloc(sizeof(char)*512); strcpy(str2, "Im here now !");
  char *str3 = malloc(sizeof(char)*512); strcpy(str3, "Goodbye World !");

  inserer_debut(pl, str1);
  inserer_debut(pl, str2);
  inserer_debut(pl, str3);

	printf("==========================================================\n"); 
	printf("Affichage de la liste :\n");
	afficher_liste(pl); 
	printf("==========================================================\n"); 

  char *test_str = pl->dupliquer((void *)str1);
  printf("Test fonction dupliquer_str() (résultat attendu -> Hello World !) : %s\n", test_str);

  pl->copier((void *)str2, (void *)test_str);
  printf("Test fonction copier_str() (résultat attendu -> Im here now !) : %s\n", test_str);

  printf("Test de la fonction afficher_str() (résultat attendu -> Goodbye World !) : "); pl->afficher((void *)str3); printf("\n\n");

  printf("Test de comparer_str(st1,test_str) : %d\n", pl->comparer((void *)str1, (void *)test_str));
	printf("Test de comparer_str(str2,test_str) : %d\n", pl->comparer((void *)str2, (void *)test_str));
	printf("Test de comparer_str(str3,test_str) : %d\n\n", pl->comparer((void *)str3, (void *)test_str));

  FILE *fw = fopen("testExo2_ecrire.txt", "w");
	pl->ecrire((const void *)str3, fw);
	pl->ecrire((const void *)str1, fw);
	fclose(fw);

  FILE *fr = fopen("testExo2_ecrire.txt", "r");
  char *test_str_lire = pl->lire(fr);
  fclose(fr);

  printf("Test de open_int() et lire_open() : %s\n", test_str_lire);

  pl->detruire((void *)str1); pl->detruire((void *)str2); pl->detruire((void *)str3); pl->detruire((void *)test_str); pl->detruire((void *)test_str_lire);
  detruire_liste(pl);
  return 0;
}
