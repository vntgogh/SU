#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>

#include "arbre_lexicographique.h"


int main(int argc, char **argv)
{
  if (argc != 3){
    printf("Usage : %s <mot à chercher> <nb de répétition>\n", argv[0]);
    return 1;
  }

  int nbRepet = atoi(argv[2]);

  PNoeud racine = lire_dico("french_za");

  // Test de la fonction afficher_dico() et lire_dico();
  //afficher_dico(racine);


  time_t begin = time(NULL);

  for(int i = 0; i < nbRepet; i++){
    int test = rechercher_mot(racine, argv[1]);
    if(test == 0){
      printf("\n%s n'est pas présent dans le dictionnaire !\n", argv[1]);
      detruire_dico(racine);
      return 1;
    }
  }

  time_t end = time(NULL);

  unsigned long secondes = (unsigned long) difftime(end, begin);
  printf("Terminé sans erreur en %ld secondes\n", secondes);

  detruire_dico(racine);

  return 0;
}

/*
./main_arbre testatrices 100000000
  > Terminé sans erreur en 21 secondes

./main_abr testatrices 20000
  > Terminé sans erreur en 19 secondes

Nous pouvons en conclure que, pour parcourir le dictionnaire en recherche d'un mot, l'arbre lexicographique est BEAUCOUP plus efficace/rapide qu'avec une simple liste chainée.
Dans ce cas là, si on part du principe que ça ait mis le même temps, on a fait 5000 fois plus de recherches pour le même dictionnaire et le même mot.
*/
