#ifndef _COMMUN_H_
#define _COMMUN_H_

#define LONGUEUR_MAX_MOT 30

#define LONGUEUR_MAX_MOT 30

// fin = il existe un mot finissant par cette lettre
// non_fin = il n'existe pas de mot finnissant par cette lettre
typedef enum _FDM {fin,non_fin} FDM;


#endif
