#include <stdio.h>
#include <stdlib.h>
#include "liste.h"
#include "abr.h"

int main(int argc, char **argv)
{
  if (argc != 3){
    printf("Usage : %s <mot à chercher> <nb de répétition>\n", argv[0]);
    exit(EXIT_SUCCESS);
  }

  int nbRepet = atoi(argv[2]);
  
  Lm_mot *french_za = lire_dico_Lmot("french_za");
  time_t begin = time(NULL);

  Lm_mot *mot = NULL;
  for(int i = 0; i < nbRepet; i++){
    mot = chercher_Lm_mot(french_za, argv[1]);

    if (!mot){
      printf("\n\n%s n'est pas présent dans le dictionnaire !\n", argv[1]);
      detruire_Lmot(french_za);
      return 1;
    }
  }

  time_t end = time(NULL);

  unsigned long secondes = (unsigned long) difftime(end, begin);
  printf("Terminé sans erreur en %ld secondes\n", secondes);

  detruire_Lmot(french_za);
  return 0;
}
