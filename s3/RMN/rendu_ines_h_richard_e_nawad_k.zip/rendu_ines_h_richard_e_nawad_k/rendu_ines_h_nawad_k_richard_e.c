#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>

#define N 100000

//bit_commun calcule le nombre de bit en commun entre x et y
//On le calcule avec la fonction log en base 2
int bit_commun(double x, double y){

    double c = -log(fabs((2*(x-y)) / (x+y))) / log(2);

    return c;
}

//bitcommun_opt fait la même chose, mais on regarde cette fois bit à bit avec un décalage et un mask
int bitcommun_opt(double x, double y){

    uint64_t a = *(uint64_t*)&x;
    uint64_t b = *(uint64_t*)&y;
    
    //On crée notre compteur à 1, car on pend en compte que le bit caché vaut 1 pour tout binaire
    int cmp = 1;

    int k = 51;

    //On utilise "1ull" au lieu de "1u" lors qu'on manipule les entiers non signés
    while (( (a & (1ull << k)) == (b & (1ull << k)) ) ){
        cmp++;
        k--;
    }
    
    return cmp;
}

//deps renvoie tous les premiers termes tels que la différence entre chaque terme et le terme qui le précède est supérieure à epsilon
double dpeps() {

    double alpha,eps,xn;

    printf("Entrez alpha, x et epsilon : \n");
    printf("alpha = ");
    scanf("%lf", &alpha);
    printf("x = ");
    scanf("%lf", &xn);
    printf("epsilon = ");
    scanf("%lf", &eps);

    printf("x0 = %.2f\n", xn);

    double x_suiv=(((4*xn - (3*alpha-2))*xn-alpha)*xn-2*alpha)/((5*xn-(4*alpha -3))*xn-2*alpha-2);

    printf("x1 = %.14f\n", x_suiv);
    int i=1;
    while(fabs(xn-x_suiv)> eps){
        //xn est le terme précedent
        xn=x_suiv; 
         
        double xn1=(((4*xn - (3*alpha-2))*xn-alpha)*xn-2*alpha);
        double xn2=((5*xn-(4*alpha -3))*xn-2*alpha-2);

        //On calcule le terme courant
        x_suiv=xn1/xn2;
        i++;

        printf("x%d = %.14f\n", i, x_suiv);
        
    }
    return x_suiv;
}


//fonction générale qui utilise le schéma de Horner pour un polynôme quelconque
double horner(double x, int n, double *p){
    double r = x * p[n] + p[n-1];
    for (int i= n-2; i > 0; i--) {
        r += x * r + p[i];
    }
    return r + p[0];
}

//appelle la fonction horner pour le polynôme au numérateur et le polynôme au dénominateur
double dpeps2(){
    double alpha,eps,xn;
    printf("Entrez alpha, x et epsilon : \n");
    scanf("%lf", &alpha);
    scanf("%lf", &xn);
    scanf("%lf", &eps);
    
    //tableau de coefficients du numérateur
    double p1[4]={-2*alpha, -alpha, -(3*alpha-2), 4};
    //tableau de coefficients du dénominateur
    double p2[3]={-2*alpha-2, -(4*alpha-3), 5};
    double x_suiv=horner(xn,4,p1)/horner(xn,3,p2);

    printf("x0 = %.14lf\n", xn);
    printf("x1 = %.14lf\n", x_suiv);
    int i=1;
    while(fabs(xn-x_suiv)>eps){
        xn=x_suiv; 

        double xn1=horner(xn,4,p1);
        double xn2=horner(xn,3,p2);
        
        x_suiv=xn1/xn2;
        i++;

        printf("x%d = %.14lf\n", i, x_suiv);
    }
    return x_suiv;
}

int main(){

    //Exercice 1
    printf("Pour x = %f et y = %f:\n",1.41421356, 1.41427845);
    printf("bit commun: %d\nbit commun optimisé: %d\n", bit_commun(1.41421356, 1.41427845), bitcommun_opt(1.41421356, 1.41427845));

    printf("Pour x = %f et y = %f:\n",9.87452334, 9.87901342);
    printf("bit commun: %d\nbit commun optimisé: %d\n", bit_commun(9.87452334, 9.87901342), bitcommun_opt(9.87452334, 9.87901342));

    printf("Pour x = %f et y = %f:\n",10.07452334, 10.07901342);
    printf("bit commun: %d\nbit commun optimisé: %d\n", bit_commun(10.07452334, 10.07901342), bitcommun_opt(10.07452334, 10.07901342));

    printf("Pour x = %f et y = %f:\n",-2.69998756, -2.70001234);
    printf("bit commun: %d\nbit commun optimisé: %d\n", bit_commun(-2.69998756, -2.70001234), bitcommun_opt(-2.69998756, -2.70001234));

    //Temps de calculs
    double x[N], y[N], un = 1;

    for (int i = 0; i < N; i++){
        x[i] = (un * rand() * 10000) / RAND_MAX;
        y[i] = x[i] + (un * rand() * 0.0001) / RAND_MAX;
    }

    clock_t debut = clock();
    for (int j = 0; j < N; j++){
        bit_commun(x[j], y[j]);
    }
    clock_t fin = clock();

    clock_t debut_opt = clock();
    for (int j = 0; j < N; j++){
        bit_commun(x[j], y[j]);
    }
    clock_t fin_opt = clock();

    printf("Temps de calcul pour bit_commun: %f\nTemps de calcule pour bitcommun_opt: %f\n", (double)(fin - debut) / CLOCKS_PER_SEC, (double)(fin_opt - debut_opt) / CLOCKS_PER_SEC);

    printf("\n\n");
    //Exercice 2
   dpeps();
   dpeps2();

    return 1;
}