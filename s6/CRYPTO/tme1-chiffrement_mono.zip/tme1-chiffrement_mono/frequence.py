import sys
from collections import Counter

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def calcul_freq(filename):
    file = open(filename, 'r') 
    text = file.read()
        
    freq = {letter: 0 for letter in alphabet}  #dico -> clé = lettre, valeur = freq
        
    for lettre in text:
        if lettre in alphabet:
            freq[lettre] += 1
        else:
            freq[lettre] = 0.0
            
    for lettre in alphabet:#calculer les pourcentages
        freq[lettre] = (freq[lettre] / len(text))*100
            
    return freq

if __name__ == "__main__":
    if len(sys.argv) != 2:
        
        print("Usage: python3 frequence.py fichier_texte", file=sys.stderr)
        sys.exit(1)
    
    filename = sys.argv[1]
    
    freq = calcul_freq(filename)
    
    for lettre in alphabet:
        print(f"{lettre} {freq[lettre]:.2f}%") 