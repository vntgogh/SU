python3 test-1-ex1-mono.py
python3 test-2-ex2-mono.py
python3 test-3-ex3-mono.py
