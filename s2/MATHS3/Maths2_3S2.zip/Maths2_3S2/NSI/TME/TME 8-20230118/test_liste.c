#include "liste_entiers.h"

int main() {
  cellule_t *ma_liste=creerListe(5);
  return 0;
}