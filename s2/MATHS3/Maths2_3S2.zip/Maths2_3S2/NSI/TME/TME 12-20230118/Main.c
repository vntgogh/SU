#include <stdio.h>
#include <stdlib.h>

#include "Othello.h"
#include "Affichage.h"
#include "ListePos.h"



int main(int argc, char **argv)
	{
	int plateau[H][H];

 	/* A COMPLETER */


	return 0;
}
