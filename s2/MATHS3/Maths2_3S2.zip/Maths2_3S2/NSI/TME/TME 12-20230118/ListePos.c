#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "ListePos.h"



/*Renvoie une cellule_t */
cellule_t *Creer_cellule(int i, int j, int val)
{
    cellule_t *nCell=NULL;
 	/* A COMPLETER */
    return nCell;
}

/*
Affiche les champs donnee des elements de la liste
*/
void Afficher_liste(cellule_t *liste)
{
 	/* A COMPLETER */
}


/*Renvoie la liste, liste à laquelle un élément de valeur d
a été ajouté en tete de liste*/
cellule_t *Inserer(int i, int j, cellule_t *liste, int val)
{
	cellule_t *n=NULL;
 	/* A COMPLETER */
	return n;
}



int Est_dans_liste(cellule_t *liste, int i, int j)
{
	int cpt=0;
 	/* A COMPLETER */
 	return cpt;
}

cellule_t *Detruire_liste(cellule_t *liste)
{
 	/* A COMPLETER */

		return NULL;
}


cellule_t *Max_liste(cellule_t *liste){

	cellule_t *best=NULL;
 	/* A COMPLETER */
	return best;
}



