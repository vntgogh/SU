#include <stdio.h>
#include <stdlib.h>
#include "ex2.h"

/* Ajoute la carte de valeur val et couleur coul EN TETE du jeu passe en parametre.
Renvoie la nouvelle tete de liste */
carte *ajouterCarte(carte  *mon_jeu, int val, int coul) {
  return NULL;
}

/* Affiche les caracteristiques d'un element de la liste */
/* NE PAS MODIFIER LA FONCTION */
void afficherCarte(carte *une_carte) {
  if (une_carte->valeur > 1 && une_carte->valeur <= 10) {
    printf("%d de ",une_carte->valeur);
  } else {
    switch(une_carte->valeur) {
      case 1 : printf("As de "); break;
      case 11 : printf("Valet de "); break;
      case 12 : printf("Dame de "); break;
      case 13 : printf("Roi de ");
    }
  }
  
  switch(une_carte->couleur) {
    case 1 : printf("trefle\n"); break;
    case 2 : printf("carreau\n"); break;
    case 3 : printf("coeur\n"); break;
    case 4 : printf("pique\n");
  }
}
  
/* Affiche toutes les cartes de la liste mon_jeu */
void afficherJeu(carte *mon_jeu){
  
}

/* Renvoie le pointeur sur la carte de valeur val et couleur coul presente dans le liste mon_jeu
   la fonction renvoie NULL si la carte n'est pas presente */
carte *trouverCarte(carte *mon_jeu, int val, int coul){
  return NULL;
}

/* Joue la carte dont la valeur et la couleur sont passees en parametre, 
  retire de la liste mon_jeu la carte jouee, renvoie la tete de liste
  Attention, si la valeur et la couleur passees en parametre ne correspondent pas a une carte de la 
  liste mon_jeu, cette derniere n'est pas modifiee */
carte *jouerCarte(carte *mon_jeu, int val, int coul){
  return NULL;
}

/* Renvoie la valeur de la paire la plus elevee presente dans la liste mon_jeu 
Renvoie -1 si le jeu ne contient aucune paire */
int trouverPaires(carte *mon_jeu) {
  return 0;
}

/* Cree une liste en recopiant de la liste passee en parametre les cartes de la couleur passee en parametre. Renvoie la tete de la nouvelle liste. La liste initiale n'est pas modifiee. Renvoie null si l aliste initiale ne contient aucune carte de la couleur demander */
carte *listeCouleur(carte *mon_jeu, int coul) {
  return NULL;
}