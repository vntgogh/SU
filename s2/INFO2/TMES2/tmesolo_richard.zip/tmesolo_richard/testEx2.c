#include <stdio.h>
#include "ex2.h"
 

/* programme de test */
int main() {
 
  return 0;
}