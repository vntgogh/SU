int  discriminant(int a, int b ,int c){
    return (b*b ) - (4 *a*c);}
