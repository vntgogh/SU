#include <stdio.h>
#include "multi_ensembles.h"

int main() {
  return 0;
}