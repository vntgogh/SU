package pobj.multiset;

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class WordCount {
	private static List<String> mots = new ArrayList<>();
	
	public static class Sortbyoccurence<T> implements Comparator<T>{
		private MultiSet<T> multi;
		
		public Sortbyoccurence(MultiSet<T> multi) {
			this.multi=multi;
		}
		@Override
		public int compare(T o1, T o2) {
			if(multi.count(o1)> multi.count(o2)) return -1;
			if(multi.count(o1) == multi.count(o2)) return 0;
			return 1;
		}
		
	}
 
	public static void wordcount(MultiSet<String> ms) throws IOException {
		String file = "data/WarAndPeace.txt"; 
		BufferedReader br = new BufferedReader(new FileReader(file)); 
		String line; 
		try{
			while ((line = br.readLine())!=null) { 
				for (String word : line.split("\\P{L}+")) { 
					if (word.equals("")) continue; // ignore les mots vides 
					//ms.add(word);
				} 
			}
		}
		catch(IllegalArgumentException e){
			System.out.println(e.toString());
		}
		
		List<String> mots;
		int cpt=0;
		if(ms instanceof NaiveMultiSet) {
			mots = ms.elements();
            cpt = 0;
            for (String mot : mots) {
                if (cpt>=10) {
                	break;
                }
                System.out.println(mot);
                cpt++;
            }
		}
		if(ms instanceof HashMultiSet) {
			mots=ms.elements();
			Collections.sort(mots,new Sortbyoccurence<String>(ms));
			cpt+=1;
			System.out.println(mots);
		}

		br.close();
	}
	
	public static void main(String[] args) {
		MultiSet<String> ml = new MultiSetDecorator<>(new HashMultiSet<>());
		try {
			wordcount(ml);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
}
