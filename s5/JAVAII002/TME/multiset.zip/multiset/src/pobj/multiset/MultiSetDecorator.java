package pobj.multiset;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class MultiSetDecorator<T> implements MultiSet<T>{
    private MultiSet<T> decorated; 

	public MultiSetDecorator(MultiSet<T> decorated) {
		this.decorated = decorated;
	}

	@Override
	public Iterator iterator() {
        return decorated.iterator(); 
	}

	@Override
	public boolean add(T e, int count) {
		boolean m = this.decorated.add(e,count);
		if(!this.decorated.isConsistent()) {
			throw new InternalError();
		}
		return m;
	}

	@Override
	public boolean add(T e) {
        boolean m = decorated.add(e); 
        if(!this.decorated.isConsistent()) {
			throw new InternalError();
		}
		return m;
	}

	@Override
	public boolean remove(Object e) {
		boolean m = decorated.remove(e); 
		if(!this.decorated.isConsistent()) {
			throw new InternalError();
		}
		return m;
	}

	@Override
	public boolean remove(Object e, int count) {
		boolean m = decorated.remove(e,count); 
		if(!(this.decorated).isConsistent()) {
			throw new InternalError();
		}
		return m;
	}

	@Override
	public int count(T o) {
		return decorated.count(o);
	}

	@Override
	public void clear() {
		decorated.clear();
	}

	@Override
	public int size() {
		return decorated.size();
	}

	@Override
	public List<T> elements() {
        return decorated.elements(); 
	}

	@Override
	public boolean isEmpty() {
		return decorated.isEmpty();
	}


	@Override
	public Object[] toArray() {
		return decorated.toArray();
	}

	@SuppressWarnings({ "hiding", "unchecked" })
	@Override
	public <T> T[] toArray(T[] a) {
		return (T[]) decorated.toArray();
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		return decorated.containsAll(c);
	}

	@Override
	public boolean addAll(Collection<? extends T> c) {
		return decorated.addAll(c);
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		return decorated.removeAll(c);
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		return decorated.retainAll(c);
	}

	@Override
	public boolean contains(Object o) {
		return decorated.contains(o);
	}

	@Override
	public boolean isConsistent() {
		return decorated.isConsistent();
	}

}
