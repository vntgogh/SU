package pobj.multiset.test;

import java.io.IOException;

import pobj.multiset.InvalidMultiSetFormat;
import pobj.multiset.MultiSet;
import pobj.multiset.MultiSetParser;

public class MultiSetParserTest {
	
	public static void main(String[] args) throws InvalidMultiSetFormat, IOException {
		MultiSet<String> multiset = MultiSetParser.parse("data/Montexte.txt");
		System.out.println(multiset);
	}
}
