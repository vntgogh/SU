package pobj.multiset;

import java.util.*;

public class NaiveMultiSet<T> extends AbstractCollection<T> implements MultiSet<T>,Iterable<T> {
	private List<T> contenu;
	private int size;
	
	public NaiveMultiSet() {
		this.contenu=new ArrayList<T>();
	}
	
    public NaiveMultiSet(Collection<T> copy) {
    	this.contenu=new ArrayList<T>();
    	for(T e : copy) {
    		this.contenu.add(e);
    		this.size++;
    	}
    	this.contenu.sort(null);
    }
    
	public boolean remove(Object e) {
		return this.contenu.remove(e);
	}

	@Override
	public boolean isEmpty() {
		return(this.contenu.isEmpty());
	}

	@Override
	public boolean contains(Object o) {
		return(this.contenu.contains(o));
	}

	@Override
	public boolean add(T e, int count) {
		for(int i=0;i<count;i++) {
			this.contenu.add(e);
			this.size++;
		}
		this.contenu.sort(null);
		return true;
	}
	
	@Override
	public boolean add(T e) {
		return(this.contenu.add(e));
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object e, int count) {
		// TODO Auto-generated method stub
		T cible=(T)e;
		
		for(int i=0;i<this.size();i++) {
			if(this.contenu.get(i)==e) {
				this.contenu.remove(i);
				count--;
				this.size--;
			}
			if(count==0) {
				return true;
			}
		}
		return true;
	}
	

	@Override
	public int count(T o) {
		int cpt=0;
		for(int i=0;i<this.size();i++) {
			if(this.contenu.get(i)==o) {
				cpt+=1;
			}
		}
		return cpt;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return this.contenu.size();
	}

	@Override
	public List<T> elements() {
		List<T> l = new ArrayList<>();
		for(T s : this) {
			if(!l.contains(s)) {
			l.add(s);
			}	
		}
		return l;
	}

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean isConsistent() {
		int tot=0;		
		for(int i=0;i<this.contenu.size();i++) {
			//Invariant : vérifier que size = nb d'éléments dans la liste
			tot+= 1;	
		}
		if(tot!=this.size) {
			return false;
		}
		return true;
	}	
}	
