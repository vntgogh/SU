package pobj.multiset.test;

import java.io.IOException;

import pobj.multiset.*;
import pobj.util.Chrono;

public class TestMultiSet {
	public static void main(String[] args) {
		MultiSet<String> hashmulti = new MultiSetDecorator<>(new HashMultiSet<>());
		MultiSet<String> naivemulti = new MultiSetDecorator<>(new NaiveMultiSet<>());
		
		System.out.println("naivemultiset");

		Chrono chrono = new Chrono();
		try {
			WordCount.wordcount(naivemulti);
		} catch (IOException e) {
			e.printStackTrace();
		}
		chrono.stop();
		chrono.affiche(0);
		
		System.out.println("hashmultiset");

		chrono = new Chrono();
		try {
			WordCount.wordcount(hashmulti);
		} catch (IOException e) {
			e.printStackTrace();
		}
		chrono.stop();
		chrono.affiche(0);
		
	}
}
