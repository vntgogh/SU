package pobj.multiset.test;


import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;
import pobj.multiset.HashMultiSet;
import pobj.multiset.MultiSet;
import pobj.multiset.MultiSetDecorator;

public class HashMultiSetTest2 {
	@Test 
	public void testAdd1() { 
	MultiSet<String> m = new MultiSetDecorator<>(new HashMultiSet<>());
	m.add("a"); 
	m.add("a",5); 
	assertEquals(6,m.count("a") ); 
	} 
	
	@Test 
	public void testAdd2() { 
	MultiSet<String> m = new MultiSetDecorator<>(new HashMultiSet<>());
	m.add("a"); 
	assertThrows(IllegalArgumentException.class, 
	() -> { m.add("a",-1); } ); 
	}
	
	@Test
	public void testRemove1() { 
	MultiSet<String> m = new MultiSetDecorator<>(new HashMultiSet<>());
	m.add("a"); 
	m.add("a",5); 
	m.remove("a",3);
	assertEquals(m.count("a"), 3); 
	} 
	
	@Test 
	public void testRemove2() {  
	MultiSet<String> m = new MultiSetDecorator<>(new HashMultiSet<>());
	m.add("a"); 
	assertThrows(IllegalArgumentException.class, 
	() -> { m.remove("a",-1); } ); 
	}
	@Test
	public void testRemove3() { // retirer un élément jamais ajouté
	MultiSet<String> m = new MultiSetDecorator<>(new HashMultiSet<>());
	m.add("a"); 
	assertThrows(IllegalArgumentException.class, 
	() -> { m.remove("b",1); } ); 
	}
	
	
	@Test 
	public void testToString() { 
	MultiSet<String> m = new HashMultiSet<>();
	m.add("a",1);
	m.add("b",2);
	m.add("c",3);
	String res="[a:1; b:2; c:3]";
	assertEquals(res,m.toString());
	}
	
	@Test
	public void testClear() {
		MultiSet<String> m = new MultiSetDecorator<>(new HashMultiSet<>());
		m.add("a",1);
		m.add("b",2);
		m.add("c",3);
		m.clear();
		assertEquals(0,m.size());
	}
	@Test
	public void testComplexe() {
		MultiSet<String> m = new MultiSetDecorator<>(new HashMultiSet<>());

	    // Ajout d'éléments au multiensemble
	    m.add("a", 5);   
	    m.add("b", 3);   
	    m.add("c", 4);
	    m.add("a", 2);   

	    // Suppression d'éléments du multiensemble
	    m.remove("b", 2);  
	    m.remove("c", 1);  
	    m.remove("a", 7);  

	    // Assertions pour vérifier l'état final du multiensemble
	    assertEquals(0,m.count("a")); 
	    assertEquals(1,m.count("b")); 
	    assertEquals(3,m.count("c")); 
	    System.out.println("Tous les tests ont réussi !");
	}
}
