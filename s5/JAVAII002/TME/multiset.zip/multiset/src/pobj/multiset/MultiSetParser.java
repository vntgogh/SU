package pobj.multiset;

import java.io.*;

public class MultiSetParser {
	
	@SuppressWarnings("resource")
	public static MultiSet<String> parse(String filename) throws InvalidMultiSetFormat, IOException{
		
        MultiSet<String> multiset = new HashMultiSet<>(); 
        
        BufferedReader buffer = null ;

        try{
           	buffer = new BufferedReader(new FileReader(filename));

           	String ligne = buffer.readLine(); // ligne lue et stockée dans la variable buf
            	
           	while(ligne!= null) {
                String[] chaineseparee = ligne.split(":"); //divise la chaine 
                
                String chaine = chaineseparee[0];
                String freqstr = chaineseparee[1];
                
                //vérifie que la ligne contient un séparateur
                if (chaineseparee.length != 2) {
                    throw new InvalidMultiSetFormat("La chaîne suivante ne contient pas de séparateur : " + ligne);
                }
                                
                try {
                    int freq = Integer.decode(freqstr);

                    //vérifie si la fréquence est positive
                    if (freq <= 0) {
                        throw new InvalidMultiSetFormat("Fréquence de cette chaîne doit être positive : " + ligne);
                    }
                    multiset.add(chaine, freq);
                } catch (NumberFormatException e) {
                    throw new InvalidMultiSetFormat("Erreur format"+freqstr,e);
                }
                
           		ligne = buffer.readLine(); // lit la ligne suivante du fichier   		
            }
        } catch (FileNotFoundException e) {
	        throw new InvalidMultiSetFormat("Fichier non trouvé", e);
        } catch (IOException e) { //erreur entrée-sortie
            throw new InvalidMultiSetFormat("Erreur entrée-sortie",e);
        }finally {
        	if(buffer != null) {
        		buffer.close();
        	}
        }
		
		return multiset;
	}
}
