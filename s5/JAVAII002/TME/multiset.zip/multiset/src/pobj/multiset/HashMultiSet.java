package pobj.multiset;
import java.util.*;
import java.util.Map.Entry;

public class HashMultiSet<T> extends AbstractCollection<T> implements MultiSet<T>,Iterable<T> {
	
	/*Contient les donnees du multi ensemble*/
    private Map<T,Integer> contenu;
    
    private int size;

    public HashMultiSet() {
    	this.contenu=new HashMap<T,Integer>();
    }
    
    public HashMultiSet(Collection<T> copy) {
    	this.contenu=new HashMap<T,Integer>();
    	for(T e : copy) {
    		this.add(e);
    	}
    }

	@Override
	public boolean add(T e, int count){
		if(e==null || count<=0) {
			throw new IllegalArgumentException();
		}
		if(this.contenu.containsKey(e)) {
			this.contenu.put(e,this.contenu.get(e)+count);
		}else {
			this.contenu.put(e,count);
		}
		this.size+=count;
		
	    assert isConsistent();

		return true;
	}

	@Override
	public boolean add(T e) {
		if(e==null) {
			throw new IllegalArgumentException();
		}
		return(this.add(e, 1));
	}

	@Override
	public boolean remove(Object e) {
		// TODO Auto-generated method stub
		if(e==null) {
			throw new IllegalArgumentException();
		}
		return this.contenu.remove(e,1);
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object e, int count) {
		// TODO Auto-generated method stub
		if(e==null || count<=0 || !this.contenu.containsKey(e)) {
			throw new IllegalArgumentException();
		}
		T cible =(T)e;
		if(this.contenu.get(e)-count>0) { //vérifie si on enlève trop
			this.contenu.put(cible,this.contenu.get(e)-count); //réduit le nb d'occ de cible
			this.size-=count; //màj de la taille
		}else{
			this.size-=this.contenu.get(e); //et on retire TOUTES ses occurences
			this.contenu.remove(cible); //sinon on retire completement cible
		}
	    
	    assert isConsistent();
	    
	    return true;
	}
	@Override
	public int count(T o) {
		// TODO Auto-generated method stub
		if(this.contenu.containsKey(o)) {
			return(this.contenu.get(o));
		}
		return 0;
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		this.contenu.clear();
		this.size=0;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return this.size;
	}

	
	
	public  class HashMultiSetIterator implements Iterator<T>{
		private Iterator<Map.Entry<T,Integer>> i;
		private T elem;
		private int n;
		
		
		public HashMultiSetIterator() {
			this.n=0;
			this.i=contenu.entrySet().iterator();
		}
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			if(i.hasNext() || n>0) {
				return true;
			}
			return false;
		}

		@Override
		public T next() {
			// TODO Auto-generated method stub
			if(n==0) {
				Map.Entry<T, Integer> suiv=i.next();
				this.elem=suiv.getKey();
				this.n=suiv.getValue();
			}
			
			this.n-=1;
			return elem;
		}
	}
	
	@Override
	public String toString() {
		StringBuilder out = new StringBuilder();
		out.append("[");
		int i=0;
		for(T e : this.contenu.keySet()) {
			if(i<this.contenu.size()-1) {
				out.append(e+":"+this.contenu.get(e)+"; ");
				i++;
			}else {
				out.append(e+":"+this.contenu.get(e)+"]");
			}
		}
		return out.toString();
	}
	
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return new HashMultiSetIterator();
	}

	@Override
	public List<T> elements() {
		List<T> l = new ArrayList<>();
		for(T s : this) {
			if(!l.contains(s)) {
			l.add(s);
			}	
		}
		return l;
	}
		
	public boolean isConsistent() {
		int tot=0;		
		for(T e : this.contenu.keySet()) {
			
			//Invariant 1 : vérifier que toutes les valeurs sont positives
			if(this.contenu.get(e)<=0) {
				return false;
			}		
			
			//Invariant 2 : vérifier que size = somme des occurences
			tot+= this.contenu.get(e);	
			
		}
		if(tot!=this.size) {
			return false;
		}
		return true;
	}
}
