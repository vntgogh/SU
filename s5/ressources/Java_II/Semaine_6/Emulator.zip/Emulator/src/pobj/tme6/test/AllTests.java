package pobj.tme6.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	TestEmulatorLoop.class,
	TestROM.class,
	TestAddressMask.class,  
	TestEmulatorLoop.class,        
	TestCPU.class,
	TestAlarm.class,        
	TestMemorySlot.class,      
	TestCPUState.class,
	TestAddressDecoder.class,          
	TestOpCode.class,
	TestClock.class,        
	TestPeriodicDevice.class,  
	TestEmulator.class,
	TestCopy.class,         
	TestRAM.class,             
})
public class AllTests {
}
