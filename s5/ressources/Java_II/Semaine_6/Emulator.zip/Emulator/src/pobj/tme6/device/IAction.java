package pobj.tme6.device;

public interface IAction {
	public void action();
}
