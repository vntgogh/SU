package pobj.tme6.notation;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.Test;

import pobj.tme6.device.Screen;

public class Q4bScreen3 {

    ByteArrayOutputStream buf = new ByteArrayOutputStream();
    PrintStream newOut = new PrintStream(buf);

	@Test
    public void testDeviceZero() {
		Screen s = new Screen();
		System.setOut(newOut);
		s.write(0,  66);
		s.tick(10);
		newOut.flush();
		assertEquals("", buf.toString());
	}

}
