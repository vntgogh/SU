package pobj.tme6.device;

// Un périphérique, qui est informé du temps qui passe
public interface IDevice {
	public void tick(int time);
}
