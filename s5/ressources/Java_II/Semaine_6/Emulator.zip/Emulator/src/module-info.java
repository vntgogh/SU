module pobj.pinboard {
	exports pobj.tme6.extra;
	requires javafx.base;
	requires javafx.graphics;
	requires transitive javafx.controls;
	requires junit;
}