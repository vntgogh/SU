package algorithms;

import characteristics.IFrontSensorResult;
import characteristics.IRadarResult;
import characteristics.Parameters;
import java.util.ArrayList;
import java.util.Random;
import robotsimulator.Brain;

public class TeamAMainBotHUANGHARRAOUILIN extends Brain {
    private enum State {
        MOVING, TURNING, FIRING, CHASING
    }

    private enum Identity {
        ROCKY, MARIO, GEORGE
    }

    private class Position {
        public double x;
        public double y;

        Position(final double x, final double y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public String toString() {
            return x + "," + y;
        }

        @Override
        public boolean equals(Object object) {
            if (object instanceof Position pos) {
                return (int) this.x == (int) pos.x && (int) this.y == (int) pos.y;
            }
            return false;
        }
    }

    // ---PARAMETERS---//
    private static final double MOVEMENT_ANGLE_PRECISION = 0.02;
    private static final double FIRING_ANGLE_PRECISION = 0.5;
    private static final double TURN_ANGLE = Math.PI / 4;
    private static final double RESET_DELAY = 5;
    private static final double SPEED = Parameters.teamAMainBotSpeed;
    private static final double RADIUS = Parameters.teamAMainBotRadius;
    private static final double FRONTAL_DETECTION_RANGE = Parameters.teamBMainBotFrontalDetectionRange;
    private static final Random RANDOM = new Random();

    // ---VARIABLES---//
    private Identity id;
    private State state;
    private double targetAngle;
    private boolean isMoving;
    private Position position;
    private Position enemyPosition;
    private double minMovement;
    private double resetDelay;

    public TeamAMainBot() {
        super();
    }

    public final void activate() {
        setIdentity();
        state = State.MOVING;
        isMoving = false;
        minMovement = 0;
        resetDelay = RESET_DELAY;
    }

    public final void step() {
        // --- Mort ---
        if (getHealth() == 0) {
            sendLogMessage("I'm dead.");
            return;
        }

        double heading = getHeading();
        boolean willCollideAlly = false;
        boolean willCollideEnemy = false;
        boolean willCollideWreck = false;
        boolean enemyDetected = false;

        // --- Radar ---
        for (IRadarResult object : detectRadar()) {
            // --- Collision ---
            if (willCollide(heading, object, RADIUS)
                    && object.getObjectType() != IRadarResult.Types.BULLET) {
                if (object.getObjectType() == IRadarResult.Types.TeamMainBot
                        || object.getObjectType() == IRadarResult.Types.TeamSecondaryBot) {
                    willCollideAlly = true;
                } else if (object.getObjectType() == IRadarResult.Types.OpponentMainBot
                        || object.getObjectType() == IRadarResult.Types.OpponentSecondaryBot) {
                    enemyDetected = true;
                    willCollideEnemy = true;
                } else if (object.getObjectType() == IRadarResult.Types.Wreck) {
                    willCollideWreck = true;
                }
            }

            // --- Cible abattue ---
            if (!enemyDetected && object.getObjectType() == IRadarResult.Types.Wreck) {
                double dist = object.getObjectDistance();
                double direction = object.getObjectDirection();
                Position wreckPosition = new Position(
                        position.x + dist * Math.cos(direction),
                        position.y + dist * Math.sin(direction));
                if (wreckPosition.equals(enemyPosition)) {
                    enemyPosition = null;
                }
            }

            // --- Partage position ennemie ---
            if (object.getObjectType() == IRadarResult.Types.OpponentMainBot
                    || object.getObjectType() == IRadarResult.Types.OpponentSecondaryBot) {
                double dist = object.getObjectDistance();
                double direction = object.getObjectDirection();
                enemyPosition = new Position(
                        position.x + dist * Math.cos(direction),
                        position.y + dist * Math.sin(direction));
                broadcast(enemyPosition.toString());
            }
        }

        // --- Ennemi déplacé ---
        if (enemyPosition != null && !enemyDetected && getDistance(enemyPosition) <= FRONTAL_DETECTION_RANGE) {
            enemyPosition = null;
        }

        // --- Réception messages ---
        ArrayList<String> messages = fetchAllMessages();
        for (String message : messages) {
            String[] enemyPos = message.split(",");
            enemyPosition = new Position(Double.valueOf(enemyPos[0]), Double.valueOf(enemyPos[1]));
        }

        // --- Détection mur ---
        if (detectFront().getObjectType() == IFrontSensorResult.Types.WALL) {
            willCollideAlly = true;
        }

        // --- Odométrie ---
        if (isMoving && !willCollideAlly && !willCollideEnemy) {
            position.x += SPEED * Math.cos(heading);
            position.y += SPEED * Math.sin(heading);
        } else if (!isMoving && state != State.TURNING) {
            resetDelay--;
            if (resetDelay <= 0) {
                minMovement = 0;
                resetDelay = RESET_DELAY;
            }
        }
        isMoving = false;

        // --- Automate ---
        switch (state) {
            case MOVING:
                if (willCollideAlly || willCollideWreck) {
                    state = State.TURNING;
                    targetAngle = normalize(heading + TURN_ANGLE * RANDOM.nextDouble(0, 1));
                    minMovement = RADIUS;
                } else {
                    actionMove();
                    if (minMovement > 0) {
                        minMovement -= SPEED;
                    } else if (enemyPosition != null) {
                        state = State.CHASING;
                    }
                }
                break;
            case TURNING:
                if (!isSameDirection(heading, targetAngle, MOVEMENT_ANGLE_PRECISION)) {
                    if (normalize(targetAngle - heading) <= Math.PI) {
                        stepTurn(Parameters.Direction.RIGHT);
                    } else {
                        stepTurn(Parameters.Direction.LEFT);
                    }
                } else {
                    state = State.MOVING;
                }
                break;
            case CHASING:
                if (enemyPosition == null) {
                    state = State.MOVING;
                    break;
                } else {
                    double enemyAngle = getAngleToPosition(enemyPosition);
                    double enemyDistance = getDistance(enemyPosition);

                    if (enemyDistance > FRONTAL_DETECTION_RANGE) {
                        if (!isSameDirection(heading, enemyAngle, MOVEMENT_ANGLE_PRECISION)) {
                            state = State.TURNING;
                            targetAngle = enemyAngle;
                            minMovement = RADIUS;
                        } else if (enemyDistance < FRONTAL_DETECTION_RANGE) {
                            state = State.FIRING;
                            if (enemyDistance > FRONTAL_DETECTION_RANGE) {
                                actionMove();
                            }
                        } else if (willCollideAlly || willCollideWreck) {
                            state = State.TURNING;
                            targetAngle = normalize(heading + TURN_ANGLE * RANDOM.nextDouble(0, 1));
                        } else {
                            actionMove();
                        }
                    } else {
                        state = State.FIRING;
                    }
                }
                break;
            case FIRING:
                if (enemyPosition != null) {
                    fire(getAngleToPosition(enemyPosition));
                    state = State.CHASING;
                } else {
                    state = State.MOVING;
                }
                break;

            default:
                break;
        }

        // --- Debug ---
        sendLogMessage(
                id.toString() + " | " +
                        "(" + (int) position.x + ", " + (int) position.y + ") | " +
                        "STATE: " + state
                        + (enemyPosition != null
                                ? " | ENEMY: (" + (int) enemyPosition.x + ", " + (int) enemyPosition.y + ")"
                                : ""));
    }

    private void setIdentity() {
        boolean allyNorth = false;
        boolean allySouth = false;

        for (IRadarResult o : detectRadar()) {
            if (o.getObjectType() == IRadarResult.Types.TeamMainBot) {
                if (isSameDirection(o.getObjectDirection(), Parameters.NORTH, MOVEMENT_ANGLE_PRECISION)) {
                    allyNorth = true;
                }
                if (isSameDirection(o.getObjectDirection(), Parameters.SOUTH, MOVEMENT_ANGLE_PRECISION)) {
                    allySouth = true;
                }
            }
        }

        if (allyNorth && allySouth) {
            id = Identity.MARIO; // Centre
            position = new Position(Parameters.teamAMainBot2InitX, Parameters.teamAMainBot2InitY);
            targetAngle = Parameters.teamAMainBot2InitHeading;
        } else if (!allyNorth) {
            id = Identity.ROCKY; // Haut
            position = new Position(Parameters.teamAMainBot1InitX, Parameters.teamAMainBot1InitY);
            targetAngle = Parameters.teamAMainBot1InitHeading;
        } else {
            id = Identity.GEORGE; // Bas
            position = new Position(Parameters.teamAMainBot3InitX, Parameters.teamAMainBot3InitY);
            targetAngle = Parameters.teamAMainBot3InitHeading;
        }
    }

    // --- FONCTIONS UTILITAIRES ---

    private boolean willCollide(double heading, IRadarResult object, double minDistance) {
        double diff = normalize(object.getObjectDirection() - heading);
        if (diff > Math.PI) {
            diff = 2 * Math.PI - diff;
        }

        // Angle de 90° (45°, 45° à gauche et droite)
        // Marge d'une distance d'un rayon du robot actuel
        if (diff < Math.PI / 2
                && object.getObjectDistance() < RADIUS + object.getObjectRadius() + minDistance) {
            return true;
        }

        return false;
    }

    private void actionMove() {
        isMoving = true;
        move();
    }

    private boolean isSameDirection(final double dir1, final double dir2, final double precision) {
        double diff = Math.abs(normalize(dir1) - normalize(dir2));
        double shortestDiff = Math.min(diff, 2 * Math.PI - diff);
        return shortestDiff < precision;
    }

    private double normalize(final double dir) {
        double res = dir % (2 * Math.PI);
        if (res < 0) {
            res += 2 * Math.PI;
        }
        return res;
    }

    private double getAngleToPosition(Position target) {
        return normalize(Math.atan2(target.y - position.y, target.x - position.x));
    }

    private double getDistance(Position target) {
        return Math
                .sqrt(Math.pow(target.x - position.x, 2) + Math.pow(target.y - position.y, 2));
    }
}
