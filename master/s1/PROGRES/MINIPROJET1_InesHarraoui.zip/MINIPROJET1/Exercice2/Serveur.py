from threading import *
from socket import *
from struct import *
from pathlib import Path

serverPort = 1234
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('', serverPort))
serverSocket.listen(5)

print('server ready')

def recvall(sock, length):
    blocks = []
    while length:
        block = sock.recv(length)
        if not block:
            raise EOFError('socket closed with %d bytes left''in this block'.format(length))
        length -= len(block)
        blocks.append(block)
    return b''.join(blocks)

header_struct = Struct("!I")
def put_block(sock, message):
    block_length = len(message)
    sock.sendall(header_struct.pack(block_length))
    sock.sendall(message)

def get_block(sock):
    data = recvall(sock, header_struct.size)
    (block_length,) = header_struct.unpack(data)
    return recvall(sock, block_length)

def get_txt(test):
    with open(test, 'rb') as f:
        return f.read().decode('utf8')

def handle_client(connectionSocket):

    message = get_block(connectionSocket).decode('utf-8')     
    print("message : ", message)

    fich = message.split('\n')[0].split(' ')[1] #recupere le 2eme mot de la 1ere ligne(fichier)
    fichier = Path(fich)

    if fichier.is_file():    
        contenu = get_txt(fichier)

        rep = "HTTP/1.1 200 OK\r\n"
        rep += "Server: BaseHTTP/0.6 Python/3.4.3\r\n"
        rep += "Content-Type: text/xml\r\n"
        rep += "Content-Length: "+str(len(contenu))+"\r\n\r\n"
        put_block(connectionSocket, (rep + contenu).encode('utf-8'))
        print("\nréponse envoyée au relai")

    else:
        rep = 'HTTP/1.1 404 Not Found\r\n\r\n'
        put_block(connectionSocket, (rep + contenu).encode('utf-8'))
    connectionSocket.close()

while True:
    connectionSocket, relaiAddress = serverSocket.accept()
    Thread(target=handle_client, args=(connectionSocket,)).start()