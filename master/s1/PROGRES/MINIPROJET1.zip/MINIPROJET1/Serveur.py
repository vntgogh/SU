from socket import *

serverPort = 1234
serverSocket = socket(AF_INET,SOCK_STREAM)
serverSocket.bind(('',serverPort))
serverSocket.listen(1)
print('server ready')

while True:
    connectionSocket, relaiAddress = serverSocket.accept()

    message = connectionSocket.recv(2048) #requete du relai

    print("message : ",message.decode('utf-8'))

    reponse = message.decode('utf-8').upper() 
    print("réponse envoyée au relai : ",reponse)
    connectionSocket.send(reponse.encode('utf-8')) #envoi au relai
    connectionSocket.close()