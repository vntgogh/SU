from socket import *

relaiName = gethostname()
relaiPort = 1235
clientSocket = socket(AF_INET,SOCK_STREAM)
clientSocket.connect((relaiName,relaiPort))

message = "abc"

clientSocket.send(message.encode('utf-8')) #envoi au relai
print("message envoyé au relai : ",message)
reponse = clientSocket.recv(2048) #reponse du relai
print("reponse : ",reponse.decode('utf-8')) 

clientSocket.close()
