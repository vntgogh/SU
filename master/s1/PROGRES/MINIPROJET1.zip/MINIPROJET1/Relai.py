from socket import *

relaiPort = 1235

serverPort = int(input("Entrer le port du serveur : "))
serverName = str(input("Entrer l'adresse IP du serveur : "))

serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('', relaiPort))
serverSocket.listen(1)
print('relai ready')

while True:
    clientConnection, address = serverSocket.accept()

    clientSocket = socket(AF_INET, SOCK_STREAM)
    clientSocket.connect((serverName, serverPort))

    message = clientConnection.recv(2048)
    clientSocket.send(message)
    print("message du client : ",message.decode('utf-8'))

    reponse = clientSocket.recv(2048)
    clientConnection.send(reponse)
    print("réponse du serveur : ",reponse.decode('utf-8'))

    clientConnection.close()
    clientSocket.close()